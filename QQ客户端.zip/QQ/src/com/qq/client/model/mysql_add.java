package com.qq.client.model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/*public class Sql{
	//public static Statement st;
		
		
		public void  getConnection() throws ClassNotFoundException, SQLException{
			try{
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/wechat";
			String name = "root";
			String pw ="123456";
			java.sql.Connection con =  DriverManager.getConnection(url, name, pw);
			System.out.println("���ӳɹ�"); 
			//return st = (Statement) con.createStatement();
			}  
	        catch(SQLException e){  
	            e.printStackTrace();  
	        }  
		}
		/*public void addid(String name,String singer) throws SQLException,ClassNotFoundException{
			this.getConnection() = getConnection(connection, source, user, password);
			String sql = "INSERT INTO music VALUES('"+singer+"','"+name+"')";
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(sql);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				connection.close();
				System.out.println("���ݿ�ɹ��ر�!");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/*
 * ���ฺ������ʷ��¼
 * �����ݿ��ȡ�������Ϸ��¼
 * �Լ������ݿ���������Ϸ��¼
 */
public class mysql_add {
	private Connection connection = null;
	private String score = null;
	private String source = "wechat";
	private String user = "root";
	private String password = "123456";
	
	// �������ݿ������
	public Connection getConnection(Connection connection,String source,String user,String password){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("�ҵ�mysql����!");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("û���ҵ�����!");
		}
		
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+source+"?characterEncoding=utf-8",user,password);
			System.out.println("���ݿ����ӳɹ�!");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("���ݿ�����ʧ��!");
		}
		return connection;
	}
	
	// ��ȡ��ǰ��߷���
	/*public String getScore(){
		String score = null;
		this.connection = getConnection(connection, source, user, password);
		String sql = "select * from score where uid = 1";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				score = resultSet.getString(2);
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();
			System.out.println("�ر����ݿ�����!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return score;
	}*/
	public void addid(String uid,String upw) throws SQLException,ClassNotFoundException{
		this.connection = getConnection(connection, source, user, password);
		String sql = "INSERT INTO user VALUES('"+uid+"','"+upw+"')";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
			System.out.println("���ݿ�ɹ��ر�!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	/*public static void main (String[] args){
		mysql_add mysql = new mysql_add();
		try {
			mysql.addid("2","2");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
}

