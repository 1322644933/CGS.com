package com.qq.client.view;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import javax.swing.*;

import com.qq.client.model.mysql_add;
public class register extends JFrame implements ActionListener{
	JLabel nameLB =new JLabel("���û��˺ţ�");
	JLabel pwLB=new JLabel("����������");
	JLabel pwLB1=new JLabel("��ȷ������");
	JTextField nameTxt=new JTextField(10);
	JTextField pwLbB=new JTextField(10);
	JTextField pwLbB1=new JTextField(10);
	mysql_add sq = new mysql_add();
	private JButton back =new JButton("ע��");
	public register(){
		this.setTitle("ע��");
		//this.setSize(220, 250);
		this.setBounds(500, 165,220, 250);
		Container c =this.getContentPane();
		c.setLayout(new FlowLayout());
		Image a = this.getToolkit().getImage("sucai/p2.png");
		this.setIconImage(a);
		String path = "15.jpg";
		
		ImageIcon background = new ImageIcon(path);  
	        // �ѱ���ͼƬ��ʾ��һ����ǩ����  
	        JLabel label = new JLabel(background);  
	        // �ѱ�ǩ�Ĵ�Сλ������ΪͼƬ�պ�����������  
	        label.setBounds(0, 0, this.getWidth(), this.getHeight());  
	        // �����ݴ���ת��ΪJPanel���������÷���setOpaque()��ʹ���ݴ���͸��  
	        JPanel imagePanel = (JPanel) this.getContentPane();  
	        imagePanel.setOpaque(false);  
	        // �ѱ���ͼƬ���ӵ��ֲ㴰�����ײ���Ϊ����  
	        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));  
	        //���ÿɼ�  
		c.add(nameLB);
		c.add(nameTxt);
		c.add(pwLB);
		c.add(pwLbB);
		c.add(pwLB1);
		c.add(pwLbB1);
		c.add(back);
		back.addActionListener(this);
		this.setVisible(true);
	} 
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("ע��")){
		//try {
			String uid= nameLB.getText();
			String upw= pwLB.getText();
			try {
				sq.addid("123", "222");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		//} catch (SQLException e1) {
			//e1.printStackTrace();
		//} catch (ClassNotFoundException e1) {
		//	e1.printStackTrace();
		}
		}
		public static void main(String[] args) {
	        // TODO Auto-generated method stub
	          register r= new  register();    
	          //int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;  
	          //int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;  
	          //r.setLocation((screenWidth - 200)/2, (screenHeight-200)/2);  
	          //-------------  end  -----------------  
	          r.setVisible(true);  
	    }
}
		
	

		//if(e.getActionCommand().equals("����������")){
		//	this.setVisible(false);
		//  Maingui().setVisible(true);
		//}
	//}
	//public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
        //String singer;
		//String name;
		//String name = outTxt.getText();
		//try {
		//	String singer= nameLB.getText();
			// name= pwLB.getText();
			//sql;
		//} catch (SQLException e1) {
			//e1.printStackTrace();
		//} catch (ClassNotFoundException e1) {
		//	e1.printStackTrace();
		//}
		
	//}
//}

