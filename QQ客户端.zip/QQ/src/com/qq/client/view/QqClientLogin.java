
package com.qq.client.view;
import com.qq.common.*;

import com.qq.client.tools.*;
import java.io.*;


import com.qq.client.model.QqClientUser;
import com.qq.common.User;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.qq.client.tools.ManageClientConServerThread;
import com.qq.client.tools.ManageQqFriendList;
import com.qq.client.view.*;
import com.qq.common.Message;
import com.qq.common.MessageType;
public class QqClientLogin extends JFrame implements ActionListener{
	// ����һ������
    Container con = this.getContentPane();
	JLabel bg = new JLabel();
	JPanel jp1;
	
	JLabel jbl1;
	JButton jb2,jb1,jb3,jb4;
	JCheckBox jc1,jc2;
	JTextField jt1,jtmibao;;

	  // �û���
    JTextField username;
    // ����
   JPasswordField password;
	public QqClientLogin(){
		this.setSize(425,330);
		this.setLocationRelativeTo(this.getOwner());
		bg.setIcon(new ImageIcon("sucai/p10.png"));
		jp1=new JPanel(new FlowLayout(FlowLayout.CENTER)); 
		jbl1 = new JLabel(new ImageIcon("sucai/p7.JPG"));
		 // ���ô���ı���ͼ��
		 Image image = new ImageIcon("sucai/p2.png").getImage();
	     this.setIconImage(image);
	     // ���ô��ڱ���
	      this.setTitle("QQ2016СС����");
	      
	        // �����С���ܸı�
	        this.setResizable(false);
	        // QQ��¼ͷ���趨
	        jb2 = new JButton();
	        Image image2 = new ImageIcon("sucai/p2.png").getImage();
	        jb2.setIcon(new ImageIcon(image2));
	        jb2.setBounds(40, 165,85, 85);
	        this.add(jb2);
	        // �û������¼�����
	        username = new JTextField();
	        username.setBounds(130, 170,194, 28);
	     // �û������¼������Աߵ�����
	        jb3 = new JButton("ע���˺�");
	        jb3.setBounds(336, 170,52, 25);
	        Image image4 = new ImageIcon("sucai/p3.png").getImage();
	        jb3.setIcon(new ImageIcon(image4));
	        jb3.setForeground(Color.BLUE); 
	        con.add(username);
	        jb3.addActionListener(this);
	        this.add(jb3);
	        // ���������
	        password = new JPasswordField();
	        password.setBounds(130, 201, 194, 28);
	        jb4 = new JButton("�һ�����");
	        jb4.setBounds(336, 202, 52,25);
	        Image image5 = new ImageIcon("sucai/p5.png").getImage();
	        jb4.setIcon(new ImageIcon(image5));
	        jb4.setForeground(Color.BLUE); 
	        con.add(password);
	        this.add(jb4);
	        // ������·�����
	        jc1 = new JCheckBox("��ס����");
	        jc1.setBounds(130, 235, 80, 15);
	        jc2 = new JCheckBox("�Զ���¼");
	        jc2.setBounds(254, 235, 80, 15);
	        this.add(jc1);
	        this.add(jc2);
	        //��¼��ť
	      jb1 = new JButton("��¼");
	        jb1.setBounds(130, 263, 195, 35);
	        Image image3 = new ImageIcon("sucai/p6.png").getImage();
	        jb1.setIcon(new ImageIcon(image3));
	        jb1.addActionListener(this);
	        this.add(jb1);
	        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.add(jp1);
		this.add(bg);
		this.setVisible(true);
		}
	public static void main(String[] args) {
		new QqClientLogin();
	}
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		//ע��
		if(arg0.getSource()==jb3)
		{ 
			new register();
		}
		//����û������¼
		
		if(arg0.getSource()==jb1)
		{
			QqClientUser qqClientUser=new QqClientUser();
			User u=new User();
			u.setUserId(username.getText().trim());
			u.setPasswd(new String(password.getPassword()));
			
			new QqFriendList("");
			if(qqClientUser.checkUser(u))
			{
			try {
					//�Ѵ��������б��������ǰ.
				QqFriendList qqList=new QqFriendList(u.getUserId());
					ManageQqFriendList.addQqFriendList(u.getUserId(), qqList);
					
					//����һ��Ҫ�󷵻����ߺ��ѵ������.
					ObjectOutputStream oos=new ObjectOutputStream
					(ManageClientConServerThread.getClientConServerThread(u.getUserId()).getS().getOutputStream());
					
					//��һ��Message
					Message m=new Message();
					m.setMesType(MessageType.message_get_onLineFriend);
					//ָ����Ҫ�������qq�ŵĺ������.
					m.setSender(u.getUserId());
					oos.writeObject(m);
				} catch (Exception e) {
					e.printStackTrace();
					// TODO: handle exception
				}
				

				//�رյ���¼����
				this.dispose();
				
				}else{
					JOptionPane.showMessageDialog(this, "��¼ʧ��");
				}
			}}}

