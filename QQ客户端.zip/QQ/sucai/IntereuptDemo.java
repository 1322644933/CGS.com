package QQjiiemian;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class IntereuptDemo extends JFrame implements ActionListener{
	private JTextField fieldText = new JTextField(100);
	private JButton buttonInterrupt = new JButton("zhongduan");

	public IntereuptDemo(){
		setLocation(100,200);
		setSize(300,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridLayout(2,1,0,0));
		getContentPane().add(fieldText);
		getContentPane().add(buttonInterrupt);
		buttonInterrupt.addActionListener(this);
		setVisible(true);
		
	}
	public void updateFiledText(){
		int k = 0;
		while (true){
			synchronized(this){
				try{this.wait(2000);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		fieldText.setText(fieldText.getText()+Integer.toString(k));
		k++;
		k%=10;
		}
	}
	public void actionPerformed(ActionEvent e) {
	if(e.getSource()== buttonInterrupt){
		fieldText.setText(fieldText.getText()+"Int");
	}
	}
	public static void main(String[] args) {
		IntereuptDemo id = new IntereuptDemo();
		id.updateFiledText();
	}

}
